package Assignment2.Test;

import Assignment2.BuzzFeedQuiz2.BuzzQuizData;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class BuzzQuizDataTest {
    @Test
    public void testGetQuestion() throws Exception {
        BuzzQuizData testData = new BuzzQuizData();
        List<String> expectedQuestion = new ArrayList<String>();
        expectedQuestion.add("Pick your beverage:");
        expectedQuestion.add("a: Coffee");
        expectedQuestion.add("b: green tea");
        expectedQuestion.add("c: beer");
        expectedQuestion.add("d: bubble tea");
        List<String> actualQuestion = testData.getQuestion(1);

        for(int i = 0; i < expectedQuestion.size(); i++) {
            assertEquals(expectedQuestion.get(i), actualQuestion.get(i));
        }
    }


    @Test
    public void testGetOutcome() throws Exception {
        BuzzQuizData testData = new BuzzQuizData();
        String expectedOutcome = "You are THE AVATAR.";
        String actualOutcome = testData.getOutcome(3);

        assertEquals(expectedOutcome, actualOutcome);
    }

    @Test
    public void testUpdateResult() throws Exception {
        BuzzQuizData testData = new BuzzQuizData();
        testData.updateResult("a");
        testData.updateResult("d");
        testData.updateResult("c");
        testData.updateResult("c");

        int expectedQuizScore[] = new int[] {1, 0, 2, 1};
        int actualQuizScore[] = testData.getQuizScore();

        assertArrayEquals(expectedQuizScore,actualQuizScore);
    }

    @Test
    public void testGetMostAnswered() throws Exception {
        BuzzQuizData testData = new BuzzQuizData();
        testData.updateResult("a");
        testData.updateResult("b");
        testData.updateResult("c");
        testData.updateResult("b");

        int expectedMostAnswered = 1;
        int actualMostAnswered = testData.getMostAnswered();

        assertEquals(expectedMostAnswered, actualMostAnswered);

    }

    @Test(expected = FileNotFoundException.class)
    public void testExceptionThrows() throws FileNotFoundException {
        throw new FileNotFoundException();
    }
}