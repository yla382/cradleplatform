package SingletonPattern;

/**
 * Created by John on 2018-12-04.
 */
public class SingletonMain {
    public static void main(String args[]) {
        MakeACaptain a = MakeACaptain.pickACaption();
        MakeACaptain b = MakeACaptain.pickACaption();
    }
}
