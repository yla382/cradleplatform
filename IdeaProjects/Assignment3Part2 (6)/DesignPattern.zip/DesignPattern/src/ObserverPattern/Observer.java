package ObserverPattern;

/**
 * Created by John on 2018-12-04.
 */
public abstract class Observer {
    public abstract void update();
}
