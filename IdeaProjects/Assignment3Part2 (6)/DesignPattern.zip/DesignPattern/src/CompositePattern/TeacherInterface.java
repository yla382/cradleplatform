package CompositePattern;

/**
 * Created by John on 2018-12-04.
 */
public interface TeacherInterface {
    public void getDetails();
}
