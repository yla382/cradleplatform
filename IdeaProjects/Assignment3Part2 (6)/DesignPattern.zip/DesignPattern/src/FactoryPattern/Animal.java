package FactoryPattern;

/**
 * Created by John on 2018-12-04.
 */
public interface Animal {
    public void speak();
}
