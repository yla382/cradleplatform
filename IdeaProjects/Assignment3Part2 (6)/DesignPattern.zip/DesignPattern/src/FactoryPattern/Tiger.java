package FactoryPattern;

/**
 * Created by John on 2018-12-04.
 */
public class Tiger implements Animal {
    @Override
    public void speak() {
        System.out.println("Tiger says: ROAR");
    }
}
