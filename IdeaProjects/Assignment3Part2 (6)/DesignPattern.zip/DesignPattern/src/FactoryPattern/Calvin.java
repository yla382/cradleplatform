package FactoryPattern;

/**
 * Created by John on 2018-12-04.
 */
public class Calvin implements Animal {
    @Override
    public void speak() {
        System.out.print("Calvin says: FUCK ME");
    }
}
