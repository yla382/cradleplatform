package Assignment2.BuzzFeedQuiz2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BuzzQuizData {
    private final String questionsPath = "src/Assignment2/TextFiles/questions.txt";
    private final String outcomesPath = "src/Assignment2/TextFiles/quizOutcomes.txt";
    private int quizScore[] = new int[] {0, 0, 0, 0,};

    public BuzzQuizData() {

    }

    public int[] getQuizScore() {
        return quizScore;
    }


    public List<String> getQuestion(int questionNumber) throws FileNotFoundException {
        List<String> chosenQuestion = new ArrayList<String>();
        File textFile = new File(questionsPath);
        Scanner scanTextFile = new Scanner(textFile);

        int startLine = (questionNumber - 1) * 6 + 1;
        int endLine = questionNumber * 6;
        int countLine = 1;

        while(scanTextFile.hasNextLine()) {
            String questionToString = scanTextFile.nextLine();
            if(countLine >= startLine && countLine <= endLine) {
                chosenQuestion.add(questionToString);
            }
            countLine++;
        }

        return chosenQuestion;
    }

    public String getOutcome(int mostPickedAnswer) throws FileNotFoundException {
        File textFile = new File(outcomesPath);
        Scanner scanTextFile = new Scanner(textFile);
        String outComeToString = null;

        for(int i = 1; i <= mostPickedAnswer + 1; i++) {
            outComeToString = scanTextFile.nextLine();
        }

        return outComeToString;
    }

    public void updateResult(String answer) {
        if(answer.equals("a")) {
            quizScore[0]++;
        }

        if(answer.equals("b")) {
            quizScore[1]++;
        }

        if(answer.equals("c")) {
            quizScore[2]++;
        }

        if(answer.equals("d")) {
            quizScore[3]++;
        }
    }

    public int getMostAnswered() {
        int mostAnswered = quizScore[0];
        int mostAnsweredIndex = 0;

        for(int i = 1; i < quizScore.length; i++) {
            if(quizScore[i] > mostAnswered) {
                mostAnsweredIndex = i;
                mostAnswered = quizScore[i];
            }
        }

        return mostAnsweredIndex;
    }

}
