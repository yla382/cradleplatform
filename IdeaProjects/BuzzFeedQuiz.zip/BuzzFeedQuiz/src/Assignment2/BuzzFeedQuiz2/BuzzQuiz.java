package Assignment2.BuzzFeedQuiz2;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class BuzzQuiz {
    private static BuzzQuizData quizData = new BuzzQuizData();

    public BuzzQuiz() {

    }

    private static void displayQuestion(int questionNumber) throws FileNotFoundException {
        List<String> chosenQuestion = quizData.getQuestion(questionNumber);
        for(int i = 0; i < chosenQuestion.size(); i++) {
            System.out.println(chosenQuestion.get(i));
        }

        String givenAnswer = new Scanner(System.in).nextLine();
        if(checkValidAnswer(givenAnswer)) {
            quizData.updateResult(givenAnswer);
        } else {
            displayQuestion(questionNumber);
        }
    }

    private static boolean checkValidAnswer(String answer) {
        String lowerCaseAnswer = answer.toLowerCase();
            if(lowerCaseAnswer.equals("a") || lowerCaseAnswer.equals("b") || lowerCaseAnswer.equals("c") || lowerCaseAnswer.equals("d")) {
                return true;
            } else {
                return false;
            }
    }

    private static void displayQuizOutcome() throws FileNotFoundException {
        int mostPickedAnswer = quizData.getMostAnswered();
        String quizOutcome = quizData.getOutcome(mostPickedAnswer);

        System.out.println(quizOutcome);
    }

    public static void main(String args[]) throws FileNotFoundException {
        ///BuzzQuizData startQuizData = new BuzzQuizData();

        displayQuestion(1);
        displayQuestion(2);
        displayQuestion(3);
        displayQuestion(4);
        displayQuestion(5);

        displayQuizOutcome();
    }
}
